getwd()
setwd("C:\\Users\\ASUS\\Desktop\\IT24100391")
getwd()

# Q1: Bus arrives uniformly between 0 and 30 minutes

punif(10, min = 0, max = 30)

1 - punif(20, min = 0, max = 30)


# Q2: Exponential with rate λ = 1/2
lambda <- 1/2

pexp(3, rate = lambda)

1 - pexp(4, rate = lambda)

pexp(4, rate = lambda) - pexp(2, rate = lambda)


# Q3: Normal(36.8, 0.4)
mu <- 36.8
sigma <- 0.4

1 - pnorm(37.9, mean = mu, sd = sigma)

pnorm(36.9, mean = mu, sd = sigma) - pnorm(36.4, mean = mu, sd = sigma)

qnorm(0.012, mean = mu, sd = sigma)

qnorm(0.99, mean = mu, sd = sigma)


