getwd()
setwd("D:\\Year 02\\Semester 01\\PS\\Lab05")
getwd()
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE, sep = ",")

fix(Delivery_Times)

attach(Delivery_Times)

names(Delivery_Times)<-c("X1")

attach(Delivery_Times)

hist(X1,main = "Histogram for Number of Delivery Times")

histogram<- hist(X1,main = "Histogram for Number of Delivery Times",breaks = seq(20,70,length= 8),right = FALSE)

breaks <- round(histogram$breaks)
breaks

freq <- histogram$counts
freq

mids <- histogram$mids
mids
classes <- c()

for(i in 1:length(breaks)-1){
  classes [i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}

cbind(Classes = classes, Frequency = freq)

lines(mids, freq)
lines
plot(mids, freq, type = "l", main = "Frequency Polygon for Delivery Times", xlab = "Delivery Times", ylab = "Frequency", ylim = c(0, max(freq)))



cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if(i == 1){
    new[i]= 0
  }else{
    new[i]= cum.freq[i-1]
  }
}
  
plot(breaks, new, type = "1", main = "Cumulative Frequency Polygon for Delivery Times", xlab = "Delivery Times", ylab = "Cumulative Frequency", ylim = c(0, max(cum.freq)))
 
cbind(Upper = breaks, CumFreq = new)
  