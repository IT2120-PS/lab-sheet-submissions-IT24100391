getwd()
setwd("C:\\Users\\IT24100391\\Desktop\\IT24100391")
data<-read.table("DATA 4.txt",header=TRUE,sep=" ")
fix(data)
attach(data)
boxplot(X1,main="Box plot for team attendance",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X2,main="Box plot for team salary",outline=TRUE,outpch=8,horizontal=TRUE)
boxplot(X3,main="Box plot for Years",outline=TRUE,outpch=8,horizontal=TRUE)

stem(X1)
stem(X2)
stem(X3)


mean(X1)
mean(X2)
mean(X3)

median(x1)
median(X2)
meadian(X3)

summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

quantile(X2)
quantile(X2)[2]
quantile(X2)[4]

quantile(X3)
quantile(X3)[2]
quantile(X3)[4]

IQR(X1)
IQR(X2)
IQR(X3)


get.mode<-FUNCTION(y){
  counts<-table(X3)
  names(counts[counts== max(counts)])
}


get.mode(X3)
table(X3)
max(counts)
counts==max(counts)
counts[counts==max(counts)]
names(count)

get.outliers<-function(z) {
  q1<-quantline(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
}

ub<-q3+1.5*iqr
lb<-q1-1.5*iqr

print(paste("upper bound = " ,ub ))
print(paste("lower bound = " ,lb ))
print(paste("Outliers:" ,paste(sort(z[z>ub]),collapse=",") ))


get.outlier(X1)
get.outliers(X2)
get.outliers(X3)



get.outliers<-function(z) {
  q1<-quntile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
}

ub<-q3+1.5*iqr
lb<-q1-1.5*iqr


print(paste("upper bound = " ,ub ))
print(paste("lower bound = " ,lb ))


print(paste("Outliers:" ,paste(sort(z[z<lb|z>ub]),collapse=",") ))

