getwd()
setwd("D:\\Year 02\\Semester 01\\PS\\lab06")
n <- 44
p <- 0.92
#02)
p_X_eq_40 <- dbinom(40, size = n, prob = p)
cat("P(X = 40) =", p_X_eq_40, "\n")

# Exercise 2
lambda <- 12
prob_exactly_15 <- dpois(15, lambda)
print(prob_exactly_15)